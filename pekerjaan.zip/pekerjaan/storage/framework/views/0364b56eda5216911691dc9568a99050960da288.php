
<?php $__env->startSection('content'); ?>
    <h1>Halaman "Unggah Lowongan" masih dalam tahap pengembangan.</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\pekerjaan\resources\views/unggah_lowongan.blade.php ENDPATH**/ ?>