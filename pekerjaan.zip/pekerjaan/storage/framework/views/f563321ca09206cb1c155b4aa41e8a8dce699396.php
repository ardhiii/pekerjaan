
<?php $__env->startSection('content'); ?>
    <center><h1>Halaman "Artikel" masih dalam tahap pengembangan.</h1></center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\pekerjaan\resources\views/artikel.blade.php ENDPATH**/ ?>