
<?php $__env->startSection('content'); ?>
    <h1>Halaman "Profil" masih dalam tahap pengembangan.</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\pekerjaan\resources\views/profil.blade.php ENDPATH**/ ?>