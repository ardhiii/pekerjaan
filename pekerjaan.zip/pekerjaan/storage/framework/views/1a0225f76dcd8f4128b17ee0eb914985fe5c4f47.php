

<?php $__env->startSection('content'); ?>
  <center>
    <div class="row mb-2" style="width: 100%;" class="pl-1 pr-1">
      <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <h3><?php echo e($user->name); ?></h3>
        <a href="/pengguna/<?php echo e($user->username); ?>">
          <div class="col-auto d-lg-block vertical-center">
              <img width="180" src="/<?php echo e($user->pp); ?>">
          </div>
        </a>
        <h5> <a href="<?php echo e($user->tautan); ?>"> <?php echo e($user->tautan); ?> </a></h5>
      </div>
    </div>
  </center>

  <h1>Info lowongan dari <?php echo e($user->name); ?>:</h1>

  <center>
    <div class="row mb-2" style="width: 100%;">
      <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6">
            <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
              <div class="col-auto d-lg-block vertical-center">
                <a href="/loker/<?php echo e($job->id); ?>">
                  <img width="180" src="/<?php echo e($job->logo); ?>">
                </a>
              </div>
              <div class="col p-4 d-flex flex-column position-static">
                <a href="/loker/<?php echo e($job->id); ?>">
                  <strong class="d-inline-block mb-2 
                  <?php echo e(($job->job_type === "Magang") ? 'text-success' : ''); ?>

                  <?php echo e(($job->job_type === "Purnawaktu") ? 'text-primary' : ''); ?>

                  <?php echo e(($job->job_type === "Sukarela") ? 'text-danger' : ''); ?>

                  <?php echo e(($job->job_type === "Paruh Waktu") ? 'text-warning' : ''); ?>

                  "><?php echo e($job->job_type); ?></strong>
                  <h3 class="mb-0"><?php echo e($job->title); ?></h3>
                  <div class="mb-1 text-muted"><?php echo e($job->name); ?></div>
                  <p class="card-text mb-auto">Waktu Registrasi: <?php echo e($job->registration_time); ?> | <?php echo e($job->loc); ?> - <?php echo e($job->method); ?></p>
                  <a style="text-align: right;"><br><br>Last updated: <?php echo e($job->updated_at->diffForHumans()); ?></a>
                </a>
              </div>  
            </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </center>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\pekerjaan\resources\views/user.blade.php ENDPATH**/ ?>