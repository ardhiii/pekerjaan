
<?php $__env->startSection('content'); ?>
  <div class="row mb-2">
    <div class="col-md-6">
      <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <div class="col p-4 d-flex flex-column position-static">
          <strong class="d-inline-block mb-2 text-primary">Jenis Pekerjaan</strong>
          <h3 class="mb-0">Judul / Peran</h3>
          <div class="mb-1 text-muted">Nama Perusahaan / Organisasi</div>
          <p class="card-text mb-auto">Waktu Registrasi &#9734; Lokasi</p>
          <a href="#" class="stretched-link">Detail</a>
        </div>
        <div class="col-auto d-lg-block">
          <img width="180" height="180" src="<?php echo e(('img/upnvj.png')); ?>">
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <div class="col p-4 d-flex flex-column position-static">
          <strong class="d-inline-block mb-2 text-success">Jenis Pekerjaan</strong>
          <h3 class="mb-0">Judul / Peran</h3>
          <div class="mb-1 text-muted">Nama Perusahaan / Organisasi</div>
          <p class="mb-auto">Waktu Registrasi &#9734; Lokasi</p>
          <a href="#" class="stretched-link">Detail</a>
        </div>
        <div class="col-auto d-lg-block">
          <img width="180" height="180" src="<?php echo e(('img/upnvj.png')); ?>">
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <div class="col p-4 d-flex flex-column position-static">
          <strong class="d-inline-block mb-2 text-success">Jenis Pekerjaan</strong>
          <h3 class="mb-0">Judul / Peran</h3>
          <div class="mb-1 text-muted">Nama Perusahaan / Organisasi</div>
          <p class="mb-auto">Waktu Registrasi &#9734; Lokasi</p>
          <a href="#" class="stretched-link">Detail</a>
        </div>
        <div class="col-auto d-lg-block">
          <img width="180" height="180" src="<?php echo e(('img/upnvj.png')); ?>">
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <div class="col p-4 d-flex flex-column position-static">
          <strong class="d-inline-block mb-2 text-success">Jenis Pekerjaan</strong>
          <h3 class="mb-0">Judul / Peran</h3>
          <div class="mb-1 text-muted">Nama Perusahaan / Organisasi</div>
          <p class="mb-auto">Waktu Registrasi &#9734; Lokasi</p>
          <a href="#" class="stretched-link">Detail</a>
        </div>
        <div class="col-auto d-lg-block">
          <img width="180" height="180" src="<?php echo e(('img/upnvj.png')); ?>">
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <div class="col p-4 d-flex flex-column position-static">
          <strong class="d-inline-block mb-2 text-success">Jenis Pekerjaan</strong>
          <h3 class="mb-0">Judul / Peran</h3>
          <div class="mb-1 text-muted">Nama Perusahaan / Organisasi</div>
          <p class="mb-auto">Waktu Registrasi &#9734; Lokasi</p>
          <a href="#" class="stretched-link">Detail</a>
        </div>
        <div class="col-auto d-lg-block">
          <img width="180" height="180" src="<?php echo e(('img/upnvj.png')); ?>">
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <div class="col p-4 d-flex flex-column position-static">
          <strong class="d-inline-block mb-2 text-success">Jenis Pekerjaan</strong>
          <h3 class="mb-0">Judul / Peran</h3>
          <div class="mb-1 text-muted">Nama Perusahaan / Organisasi</div>
          <p class="mb-auto">Waktu Registrasi &#9734; Lokasi</p>
          <a href="#" class="stretched-link">Detail</a>
        </div>
        <div class="col-auto d-lg-block">
          <img width="180" height="180" src="<?php echo e(('img/upnvj.png')); ?>">
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <div class="col p-4 d-flex flex-column position-static">
          <strong class="d-inline-block mb-2 text-success">Jenis Pekerjaan</strong>
          <h3 class="mb-0">Judul / Peran</h3>
          <div class="mb-1 text-muted">Nama Perusahaan / Organisasi</div>
          <p class="mb-auto">Waktu Registrasi &#9734; Lokasi</p>
          <a href="#" class="stretched-link">Detail</a>
        </div>
        <div class="col-auto d-lg-block">
          <img width="180" height="180" src="<?php echo e(('img/upnvj.png')); ?>">
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <div class="col p-4 d-flex flex-column position-static">
          <strong class="d-inline-block mb-2 text-success">Jenis Pekerjaan</strong>
          <h3 class="mb-0">Judul / Peran</h3>
          <div class="mb-1 text-muted">Nama Perusahaan / Organisasi</div>
          <p class="mb-auto">Waktu Registrasi &#9734; Lokasi</p>
          <a href="#" class="stretched-link">Detail</a>
        </div>
        <div class="col-auto d-lg-block">
          <img width="180" height="180" src="<?php echo e(('img/upnvj.png')); ?>">
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <div class="col p-4 d-flex flex-column position-static">
          <strong class="d-inline-block mb-2 text-success">Jenis Pekerjaan</strong>
          <h3 class="mb-0">Judul / Peran</h3>
          <div class="mb-1 text-muted">Nama Perusahaan / Organisasi</div>
          <p class="mb-auto">Waktu Registrasi &#9734; Lokasi</p>
          <a href="#" class="stretched-link">Detail</a>
        </div>
        <div class="col-auto d-lg-block">
          <img width="180" height="180" src="<?php echo e(('img/upnvj.png')); ?>">
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <div class="col p-4 d-flex flex-column position-static">
          <strong class="d-inline-block mb-2 text-success">Jenis Pekerjaan</strong>
          <h3 class="mb-0">Judul / Peran</h3>
          <div class="mb-1 text-muted">Nama Perusahaan / Organisasi</div>
          <p class="mb-auto">Waktu Registrasi &#9734; Lokasi</p>
          <a href="#" class="stretched-link">Detail</a>
        </div>
        <div class="col-auto d-lg-block">
          <img width="180" height="180" src="<?php echo e(('img/upnvj.png')); ?>">
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\mbkm\pekerjaan\resources\views/beranda.blade.php ENDPATH**/ ?>