

<?php $__env->startSection('container'); ?>
  <a href="/dashboard/lowongan" class="btn btn-success">
    <span data-feather="arrow-left"></span> Kembali ke daftar info lowongan saya
  </a>
  <a href="/dashboard/lowongan/<?php echo e($job->id); ?>/edit" class="btn btn-warning">
    <span data-feather="edit"></span> Ubah
  </a>
  
  <form action="/dashboard/lowongan/<?php echo e($job->slug); ?>" method="POST" class="d-inline">
    <?php echo method_field('delete'); ?>
    <?php echo csrf_field(); ?>
    <button class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus info lowongan?')">
      <span data-feather="x-circle"></span> Hapus
    </button>
  </form>
  <div class="row mb-2"> 
    <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
      <center>
        <div class="col-auto d-lg-block" style="padding-top: 10px;">
          <img width="180" src="/<?php echo e($job->logo); ?>">
        </div>
      </center>
      <div class="col p-4 d-flex flex-column position-static">
        <strong class="d-inline-block mb-2 <?php echo e(($job->job_type === "Magang") ? 'text-success' : (($job->job_type === "Purnawaktu") ? 'text-primary' : 'text-danger')); ?>"><?php echo e($job->job_type); ?></strong>
        <h3 class="mb-0"><?php echo e($job->title); ?></h3>
        <div class="mb-1 text-muted"><?php echo e($job->name); ?></div>
        <p class="card-text mb-auto">Waktu Registrasi: <?php echo e($job->registration_time); ?> | <?php echo e($job->loc); ?> - <?php echo e($job->method); ?></p>
        <p style="text-align: left;"><br><b>Kriteria pelamar:</b><br>
        Pendidikan minimal: <?php echo e($job->education); ?><br>
        Jurusan: <?php echo e($job->major); ?><br>
        Kriteria lainnya: <br><?php echo e($job->criteria); ?><br>
        <br><b>Deskripsi:</b><br><?php echo e($job->description); ?><br>
        <br><b>Cara Melamar:</b> <br><?php echo e($job->apply); ?><br>
        <br><b>Narahubung:</b> <br><?php echo e($job->cp); ?><br>
        <br><b>Tentang Perusahaan / Organisasi:</b> <br>
        <u>Nama Resmi:</u> <br>
        <?php echo e($job->legal_name); ?><br><br>
        <u>Lokasi:</u> <br>
        <?php echo e($job->address); ?>, Kec. <?php echo e($job->district); ?>, <?php echo e($job->city); ?>, <?php echo e($job->province); ?><br><br>
        <u>Kategori:</u> <br>
        <?php echo e($job->company_type); ?><br><br>
        <u>Jumlah Pekerja:</u> <br>
        <?php echo e($job->employees); ?> pekerja<br><br>
        <u>Profil:</u> <br>
        <?php echo e($job->profile); ?><br>
        <br><b>Sumber Info:</b> <br><a href="<?php echo e($job->source); ?>"><?php echo e($job->source); ?></a><br>
        <br><b>Flyer / Poster:</b> <br><img src="/<?php echo e($job->flyer); ?>" style="max-width: 100%"/></p>
        <p style="text-align: right;"><br>Last updated: <?php echo e(\Carbon\Carbon::parse($job['updated_at'])->diffForHumans()); ?></p>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\pekerjaan\resources\views/dashboard/jobs/show.blade.php ENDPATH**/ ?>